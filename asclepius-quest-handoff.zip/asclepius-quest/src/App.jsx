import { useState, useEffect, useCallback, useRef } from "react";

const P = {
  bg: "#FFF8F3", card: "#FFFFFF", primary: "#C4A882", accent: "#D4877F",
  teal: "#7EBDB4", lav: "#B5A8D5", pink: "#E8B4C8", gold: "#E8C872",
  text: "#3A3632", muted: "#9B9490", border: "#EDE5DC", ok: "#7EBDB4", ng: "#D4877F",
  xpBar: "linear-gradient(90deg, #B5A8D5, #D4877F, #E8C872)",
};

const ALL_CARDS = [
  { id:"c1", name:"太陽神アポロン", r:"★★", color:"#E8C872", e:"☀️", desc:"音楽・医術・予言の神", step:1 },
  { id:"c2", name:"愛の神キューピッド", r:"★", color:"#E8B4C8", e:"💘", desc:"愛の矢を放つ神", step:1 },
  { id:"c3", name:"月桂樹のダプネ", r:"★", color:"#7EBDB4", e:"🌿", desc:"月桂樹に姿を変えた", step:1 },
  { id:"c4", name:"ミダス王", r:"★★", color:"#B5A8D5", e:"👑", desc:"ロバの耳に変えられた王", step:1 },
  { id:"c5", name:"母コロニス", r:"★★", color:"#E8B4C8", e:"🕊️", desc:"カラスの乙女", step:2 },
  { id:"c6", name:"師ケイロン", r:"★★", color:"#7EBDB4", e:"🐴", desc:"ケンタウロス族の賢者", step:2 },
  { id:"c7", name:"白いカラス", r:"★", color:"#C4A882", e:"🐦‍⬛", desc:"かつては純白だった", step:2 },
  { id:"c8", name:"帝王切開の秘術", r:"★★★", color:"#D4877F", e:"⚕️", desc:"世界初の帝王切開", step:2 },
  { id:"c9", name:"ケイロンの薬箱", r:"★★★", color:"#7EBDB4", e:"💊", desc:"秘薬中の秘薬", step:3 },
  { id:"c10", name:"薬指の由来", r:"★★", color:"#B5A8D5", e:"💍", desc:"薬を塗る指", step:3 },
  { id:"c11", name:"エピオネ", r:"★★", color:"#E8B4C8", e:"👩‍⚕️", desc:"鎮痛と看護の女神", step:4 },
  { id:"c12", name:"蛇遣い座", r:"★★★★", color:"#E8C872", e:"⭐", desc:"ゼウスが遺した星座", step:5 },
];

const STEPS = [
  { id:1, name:"アポロンの章", icon:"☀️", color:P.gold, questions:["q1","q2","q3","q4","q5"] },
  { id:2, name:"コロニスの章", icon:"🕊️", color:P.pink, questions:["q6","q7","q8","q9"] },
  { id:3, name:"ケイロンの章", icon:"🐴", color:P.teal, questions:["q10","q11","q12"] },
  { id:4, name:"試練の章", icon:"⚡", color:P.lav, questions:["q13","q14","q15"] },
  { id:5, name:"ゼウスの裁き", icon:"🌟", color:P.accent, questions:["boss"] },
];

const STORY_CHAPTERS = [
  { title: "P.0 ヒポクラテスの誓い", text: "紀元前4世紀、ヒポクラテスは「医の倫理」を説きました。原始的な医学から迷信や呪術を切り離し、科学的な医学を発展させた「医学の独立宣言」をした人です。", icon: "📜" },
  { title: "P.1 医神アスクレピオス", text: "ギリシア神話の医学の神。杖に蛇の巻きついたモチーフは『アスクレピオスの杖』と呼ばれ、救急医療のシンボル「スター・オブ・ライフ」で用いられています。", icon: "🐍" },
  { title: "P.2 アポロンの栄光", text: "アポロンは太陽の神にして音楽・道徳・哲学・医術の神。ゼウスとレトの息子で、双子の妹アルテミス（月神）と共にデロス島で生まれました。", icon: "☀️" },
  { title: "P.3 王様の耳はロバの耳", text: "パンとの演奏対決でミダス王がパンの勝ちと主張。怒ったアポロンはミダス王の耳をロバの耳に変えました。秘密を知った床屋は地面の穴に叫び、そこから葦が生えて秘密が広まりました。", icon: "👑" },
  { title: "P.4 愛の神キューピッド", text: "エロスの金の矢はアポロンに、鉛の矢はダプネに。アポロンは恋に落ちるもダプネは逃げ、月桂樹に姿を変えました。以来、月桂冠はアポロンの象徴に。", icon: "💘" },
  { title: "P.5 母コロニスの悲劇", text: "コロニスはアポロンの子を身篭りますが、カラスの報告をきっかけにアポロンの怒りを買い、妹アルテミスの矢で命を落とします。アスクレピオスは世界初の帝王切開で誕生しました。", icon: "🕊️" },
  { title: "P.6 師ケイロンの教え", text: "ケンタウロス族の賢者ケイロンの元で育てられたアスクレピオス。薬草学、外科手術、処方の技術を学び、やがて師をも超える医術の持ち主に成長します。", icon: "🐴" },
  { title: "P.7 ゼウスの裁き", text: "死者を蘇らせる力を持つまでになったアスクレピオスを、冥界の秩序を乱すとしてゼウスは雷で打ちました。死後、その姿は蛇遣い座として星座に残されました。", icon: "⚡" },
];

const QDB = {
  q1: { title:"問1 イメージ理解", sub:"絵と物語の節を対応させよう", mechanic:"スワイプ", step:1,
    items:[
      { emoji:"💘", scene:"天使が弓を構える", ans:"e", ansText:"P.4 愛の神キューピッド" },
      { emoji:"👑", scene:"王様がターバンで耳を隠す", ans:"d", ansText:"P.3 王様の耳はロバの耳" },
      { emoji:"🐍", scene:"蛇と杖のシンボル", ans:"b", ansText:"P.1 医神アスクレピオス" },
    ],
    opts:[{id:"a",l:"P.0 ヒポクラテスの誓い"},{id:"b",l:"P.1 医神アスクレピオス"},{id:"c",l:"P.2 父アポロン"},{id:"d",l:"P.3 王様の耳はロバの耳"},{id:"e",l:"P.4 愛の神キューピッド"},{id:"f",l:"関係しない"}],
  },
  q2: { title:"問2 接続詞パズル", sub:"文脈にふさわしい接続詞を選ぼう", mechanic:"パズル", step:1,
    blanks:[
      { id:"ア", ctx:"それぞれに決められた職分がありました。(　)ギリシア神話では…", ans:"また、", hint:"追加情報" },
      { id:"イ", ctx:"神々と人間を分かつ点が一つだけありました。(　)神々は絶対に死なないし…", ans:"それは、", hint:"前文を説明" },
      { id:"ウ", ctx:"人間は必ず死ぬという一点です。(　)神々の場合には…", ans:"ただし、", hint:"条件追加" },
    ],
    choices:["すると、","また、","しかし、","ただし、","それは、"],
  },
  q3: { title:"問3 漢字バトル", sub:"ひらがなを正しい漢字に！", mechanic:"バトル", step:1,
    words:[
      { h:"すがたかたち", a:"姿形", opts:["姿形","姿方","容形","姿態"] },
      { h:"のうりょく", a:"能力", opts:["能力","脳力","農力","能利"] },
      { h:"おんがく", a:"音楽", opts:["音楽","音学","恩楽","穏楽"] },
      { h:"いがく", a:"医学", opts:["医学","異学","衣学","意学"] },
    ],
  },
  q4: { title:"問4 要約チャレンジ", sub:"38字以内で要約しよう", mechanic:"要約", step:1, max:38,
    passage:"音楽の神アポロンとパンの演奏対決で、ミダス王だけがパンの勝ちと主張。怒ったアポロンはミダス王の耳をロバの耳に変えた。",
  },
  q5: { title:"問5 知恵カード", sub:"慣用句をマスターしよう", mechanic:"収集", step:1,
    items:[
      { q:"「腑に落ちない」の意味は？", opts:["胃が痛い","納得できない","忘れる","興味がない"], ans:1, e:"🤔" },
      { q:"「匙を投げる」の意味は？", opts:["料理が下手","諦める","怒る","驚く"], ans:1, e:"🥄" },
      { q:"「案ずるより生むが易し」の意味は？", opts:["出産は簡単","計画が大切","心配より実行が簡単","考えすぎ注意"], ans:2, e:"💡" },
    ],
  },
  q6: { title:"問6 イメージ理解II", sub:"P.5〜7の節と絵を対応させよう", mechanic:"スワイプ", step:2,
    items:[
      { emoji:"🕊️", scene:"美しい女性とカラス", ans:"a", ansText:"P.5 母コロニス" },
      { emoji:"🐴", scene:"半人半馬の賢者", ans:"b", ansText:"P.6 師ケイロン" },
      { emoji:"🌿", scene:"薬草を調合する場面", ans:"c", ansText:"P.7 医学教育" },
    ],
    opts:[{id:"a",l:"P.5 母コロニス"},{id:"b",l:"P.6 師ケイロン"},{id:"c",l:"P.7 医学教育"},{id:"d",l:"関係しない"}],
  },
  q7: { title:"問7 接続詞パズルII", sub:"コロニスの物語の接続詞を埋めよう", mechanic:"パズル", step:2,
    blanks:[
      { id:"1", ctx:"アポロンは噂を聞き山を降りてきました。(　)そこで出逢った二人は恋に落ちました。", ans:"ところが、", hint:"意外な展開" },
      { id:"2", ctx:"アポロンは忙しく一緒にいられません。(　)嫉妬深いアポロンはカラスを預けました。", ans:"そこで、", hint:"理由から行動" },
      { id:"3", ctx:"美しいとはいえないカラスだったかというと、(　)当時のカラスは純白でした。", ans:"なぜ、", hint:"理由の疑問" },
    ],
    choices:["ところが、","そこで、","なぜ、","しかし、","つまり、"],
  },
  q8: { title:"問8 推測力", sub:"物語の結末を推測しよう", mechanic:"推理", step:2,
    items:[
      { q:"カラスは罰として羽を何色に変えられた？",
        opts:["灰色","黒色","茶色","赤色"], ans:1, e:"🐦‍⬛",
        explain:"嘘の報告をしたカラスは真っ黒に変えられました" },
      { q:"アスクレピオスの誕生はどのような方法だった？",
        opts:["自然分娩","帝王切開","神の奇跡","養子"], ans:1, e:"⚕️",
        explain:"世界で初めて帝王切開で生まれた子供です" },
    ],
  },
  q9: { title:"問9 語源探検", sub:"医療用語の語源を知ろう", mechanic:"探検", step:2,
    items:[
      { q:"「帝王切開」の由来として正しいのは？",
        opts:["帝王が命じた手術","カエサルの出生伝説から","王の治療法","帝国の医学"], ans:1, e:"📖" },
      { q:"「奈落」の元々の意味は？",
        opts:["地獄の底","舞台の床下","暗い洞窟","深い穴"], ans:1, e:"🕳️" },
    ],
  },
  q10: { title:"問10 漢字バトルII", sub:"ケイロンの章の漢字に挑戦", mechanic:"バトル", step:3,
    words:[
      { h:"ほうぶつ", a:"怪物", opts:["怪物","壊物","介物","快物"] },
      { h:"けんじゃ", a:"賢者", opts:["賢者","剣者","検者","兼者"] },
      { h:"しょほう", a:"処方", opts:["処方","所方","書方","初方"] },
      { h:"ちりょう", a:"治療", opts:["治療","知量","地量","治量"] },
    ],
  },
  q11: { title:"問11 タイトル命名", sub:"物語にタイトルをつけよう", mechanic:"要約", step:3, max:15,
    passage:"ケイロンは診療の際に必ずアスクレピオスを傍らにおき、薬草の使い方、手当ての方法を実践的に教えていました。",
  },
  q12: { title:"問12 師弟問答", sub:"深い意味を理解しよう", mechanic:"問答", step:3,
    items:[
      { q:"「処方」の本来の意味は？", opts:["薬を出すこと","方法を処置すること","病気を処理すること","薬の配合と用法を指示"], ans:3, e:"📋" },
      { q:"「手当て」の語源的な意味は？", opts:["給料","患部に手を当てること","道具を準備すること","応急処置"], ans:1, e:"🤲" },
      { q:"「風上にも置けない」はなぜそう言う？", opts:["風が強い場所だから","臭くて風上に置くと臭いが来る","風上は危険だから","風上は偉い場所"], ans:1, e:"💨" },
      { q:"「薬指」はなぜ薬指と呼ぶ？", opts:["薬を飲む時に使う","薬を塗る時にこの指を使った","薬の形に似ている","薬師如来の指"], ans:1, e:"💍" },
    ],
  },
  q13: { title:"問13 並べ替え", sub:"出来事を正しい順に並べよう", mechanic:"タイムライン", step:4,
    items:[
      { fragments:[
          {id:"a",text:"ケイロンが薬草の使い方を教えた"},
          {id:"b",text:"アスクレピオスが擦り傷を作った"},
          {id:"c",text:"シャクヤクで傷を治療した"},
          {id:"d",text:"アスクレピオスの医術が師を超えた"},
        ],
        correctOrder:["b","a","c","d"],
      },
    ],
  },
  q14: { title:"問14 接続詞パズルIII", sub:"最終章の接続詞を完成させよう", mechanic:"パズル", step:4,
    blanks:[
      { id:"ア", ctx:"象牙造りの薬箱から秘薬を取り出し、三度呪文を唱えました。(　)その三度目が終わらないうちに…", ans:"すると、", hint:"結果" },
      { id:"イ", ctx:"蘇生術を施す力を得ました。(　)ゼウスは冥界の秩序が乱れると考えました。", ans:"しかし、", hint:"逆接" },
    ],
    choices:["すると、","しかし、","また、","つまり、","さらに、"],
  },
  q15: { title:"問15 論理パラドックス", sub:"エピメニデスの矛盾を解け！", mechanic:"論理", step:4,
    items:[
      { q:"「すべてのクレタ島人は嘘つきだ」とクレタ島人が言った。矛盾の理由は？",
        opts:[
          "クレタ島人が本当のことを言っている→嘘つきではない→矛盾",
          "クレタ島人は全員正直者だから",
          "嘘つきは存在しないから",
          "クレタ島は実在しないから"
        ], ans:0, e:"🤯",
        explain:"発言者もクレタ島人なので、この発言が真なら自分も嘘つき→発言は嘘→矛盾が生じます" },
    ],
  },
  boss: { title:"最終試練 ゼウスの裁き", sub:"全Stepの知識を総動員せよ！", mechanic:"ボス戦", step:5,
    items:[
      { q:"アスクレピオスの杖のシンボルに巻きつくものは？", opts:["竜","蛇","鎖","蔦"], ans:1, e:"🐍" },
      { q:"アスクレピオスを育てた賢者の名前は？", opts:["ゼウス","アポロン","ケイロン","ハデス"], ans:2, e:"🐴" },
      { q:"ゼウスがアスクレピオスを罰した理由は？", opts:["神に反抗した","死者を蘇らせた","薬を盗んだ","人間に味方した"], ans:1, e:"⚡" },
      { q:"アスクレピオスの死後、姿を変えられた星座は？", opts:["オリオン座","蛇遣い座","ヘルクレス座","白鳥座"], ans:1, e:"⭐" },
      { q:"「医術は生に奉仕する業であって…」の続きは？", opts:["死を防ぐ業","生を創り出す業ではない","永遠の命を与える業","全てを癒す業"], ans:1, e:"📜" },
    ],
  },
};

function shuffle(a){const b=[...a];for(let i=b.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[b[i],b[j]]=[b[j],b[i]];}return b;}

function ProgressDots({total,current,done}){
  return <div style={{display:"flex",gap:4,justifyContent:"center",margin:"8px 0"}}>
    {Array.from({length:total}).map((_,i)=>(
      <div key={i} style={{width:28,height:4,borderRadius:2,transition:"all 0.3s",
        background:i<done?P.teal:i===current?P.accent:P.border}}/>
    ))}
  </div>;
}

function CardReveal({card,onClose}){
  const[phase,setPhase]=useState(0);
  useEffect(()=>{const a=setTimeout(()=>setPhase(1),100);const b=setTimeout(()=>setPhase(2),500);return()=>{clearTimeout(a);clearTimeout(b);};},[]);
  return <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.6)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,opacity:phase>=1?1:0,transition:"opacity 0.3s"}}>
    <div style={{width:200,padding:"28px 20px",borderRadius:20,background:`linear-gradient(135deg,${card.color}22,${card.color}44)`,border:`2px solid ${card.color}`,textAlign:"center",transform:phase>=2?"scale(1) rotateY(0)":"scale(0.4) rotateY(90deg)",transition:"transform 0.5s cubic-bezier(0.34,1.56,0.64,1)",boxShadow:`0 0 40px ${card.color}66`}}>
      <div style={{fontSize:44}}>{card.e}</div>
      <div style={{fontSize:10,color:card.color,marginTop:6,letterSpacing:2}}>{card.r}</div>
      <div style={{fontSize:15,fontWeight:700,color:P.text,marginTop:4}}>{card.name}</div>
      <div style={{fontSize:11,color:P.muted,marginTop:4}}>{card.desc}</div>
      <div style={{fontSize:10,color:P.muted,marginTop:12}}>タップして閉じる</div>
    </div>
  </div>;
}

function SelectQuiz({data,onDone}){
  const items=data.items||[];const opts=data.opts||[];
  const[step,setStep]=useState(0);const[sel,setSel]=useState(null);const[res,setRes]=useState(null);const[sc,setSc]=useState(0);
  const item=items[step];if(!item)return null;
  const handle=(id)=>{if(res!==null)return;setSel(id);const ok=id===item.ans;setRes(ok);if(ok)setSc(s=>s+1);
    setTimeout(()=>{if(step<items.length-1){setStep(s=>s+1);setSel(null);setRes(null);}else onDone(sc+(ok?1:0),items.length);},1000);};
  return <div>
    <ProgressDots total={items.length} current={step} done={step}/>
    <div style={{background:"linear-gradient(135deg,#F5EDE4,#EDE3D8)",borderRadius:14,padding:"20px 16px",textAlign:"center",marginBottom:14}}>
      <div style={{fontSize:40,marginBottom:6}}>{item.emoji||item.e}</div>
      <div style={{fontSize:14,fontWeight:600,color:P.text}}>{item.scene||item.q}</div>
      {item.explain&&res!==null&&<div style={{fontSize:11,color:P.ok,marginTop:8,lineHeight:1.6}}>💡 {item.explain}</div>}
    </div>
    <div style={{display:"grid",gridTemplateColumns:opts.length>4?"1fr":"1fr 1fr",gap:8}}>
      {(opts.length?opts:item.opts).map((o,i)=>{
        const oid=typeof o==="object"?o.id:i;const label=typeof o==="object"?o.l:o;
        const isOk=res!==null&&oid===item.ans;const isNg=res===false&&oid===sel;
        return <button key={i} onClick={()=>handle(oid)} style={{padding:"11px 10px",borderRadius:11,border:`1.5px solid ${isOk?P.ok:isNg?P.ng:P.border}`,fontSize:12,fontWeight:500,cursor:res!==null?"default":"pointer",background:isOk?P.ok+"18":isNg?P.ng+"18":"#fff",color:P.text,transition:"all 0.2s",transform:isOk?"scale(1.03)":"scale(1)",textAlign:"left"}}>
          {label}
        </button>;
      })}
    </div>
  </div>;
}

function BlankQuiz({data,onDone}){
  const blanks=data.blanks||[];const choices=data.choices||[];
  const[step,setStep]=useState(0);const[sel,setSel]=useState(null);const[res,setRes]=useState(null);const[sc,setSc]=useState(0);
  const b=blanks[step];if(!b)return null;
  const handle=(c)=>{if(res!==null)return;setSel(c);const ok=c===b.ans;setRes(ok);if(ok)setSc(s=>s+1);
    setTimeout(()=>{if(step<blanks.length-1){setStep(s=>s+1);setSel(null);setRes(null);}else onDone(sc+(ok?1:0),blanks.length);},1000);};
  return <div>
    <ProgressDots total={blanks.length} current={step} done={step}/>
    <div style={{background:"#F9F5F0",borderRadius:12,padding:"14px 14px",marginBottom:12,fontSize:13,lineHeight:1.8,color:P.text,borderLeft:`3px solid ${P.lav}`}}>
      {b.ctx.split("(　)").map((p,i,a)=><span key={i}>{p}{i<a.length-1&&<span style={{display:"inline-block",minWidth:56,padding:"2px 8px",margin:"0 2px",background:res!==null?(res?P.ok+"28":P.ng+"28"):P.lav+"28",borderRadius:6,border:`1.5px dashed ${res!==null?(res?P.ok:P.ng):P.lav}`,textAlign:"center",fontWeight:600,fontSize:12,color:res!==null?(res?P.ok:P.ng):P.lav}}>{sel||"？"}</span>}</span>)}
      <div style={{fontSize:10,color:P.muted,marginTop:6}}>💡 {b.hint}</div>
    </div>
    <div style={{display:"flex",flexWrap:"wrap",gap:6,justifyContent:"center"}}>
      {choices.map(c=>{const isOk=res!==null&&c===b.ans;const isNg=res===false&&c===sel;
        return <button key={c} onClick={()=>handle(c)} style={{padding:"8px 16px",borderRadius:20,fontSize:13,fontWeight:600,border:`2px solid ${isOk?P.ok:isNg?P.ng:P.border}`,background:isOk?P.ok+"15":isNg?P.ng+"15":"#fff",color:isOk?P.ok:isNg?P.ng:P.text,cursor:res!==null?"default":"pointer",transition:"all 0.2s",transform:isOk?"scale(1.06)":"scale(1)"}}>{c}</button>;
      })}
    </div>
  </div>;
}

function KanjiQuiz({data,onDone}){
  const words=data.words||[];
  const[step,setStep]=useState(0);const[res,setRes]=useState(null);const[sc,setSc]=useState(0);
  const[time,setTime]=useState(45);const[sOpts,setSOpts]=useState([]);
  const w=words[step];
  useEffect(()=>{if(w)setSOpts(shuffle(w.opts));},[step]);
  useEffect(()=>{if(time<=0){onDone(sc,words.length);return;}const t=setInterval(()=>setTime(v=>v-1),1000);return()=>clearInterval(t);},[time]);
  if(!w)return null;
  const handle=(o)=>{if(res!==null)return;const ok=o===w.a;setRes(ok);if(ok)setSc(s=>s+1);
    setTimeout(()=>{if(step<words.length-1){setStep(s=>s+1);setRes(null);}else onDone(sc+(ok?1:0),words.length);},700);};
  return <div>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
      <span style={{fontSize:11,color:P.accent,fontWeight:600}}>{step+1}/{words.length}</span>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <div style={{width:80,height:5,borderRadius:3,background:P.border,overflow:"hidden"}}>
          <div style={{width:`${(time/45)*100}%`,height:"100%",borderRadius:3,transition:"width 1s linear",background:time>15?P.teal:time>7?P.gold:P.ng}}/>
        </div>
        <span style={{fontSize:11,fontWeight:700,color:time>7?P.text:P.ng,fontVariantNumeric:"tabular-nums"}}>{time}s</span>
      </div>
    </div>
    <div style={{textAlign:"center",padding:"22px 16px",borderRadius:14,background:"linear-gradient(135deg,#F5EDE4,#EDE3D8)",marginBottom:14}}>
      <div style={{fontSize:10,color:P.muted,marginBottom:4}}>漢字に変換</div>
      <div style={{fontSize:26,fontWeight:800,color:P.accent,letterSpacing:3}}>{w.h}</div>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
      {sOpts.map(o=>{const isOk=res!==null&&o===w.a;
        return <button key={o} onClick={()=>handle(o)} style={{padding:"12px",borderRadius:12,fontSize:18,fontWeight:700,letterSpacing:2,border:`2px solid ${isOk?P.ok:P.border}`,background:isOk?P.ok+"12":"#fff",color:isOk?P.ok:P.text,cursor:res!==null?"default":"pointer",transition:"all 0.2s",opacity:res!==null&&!isOk?0.35:1}}>{o}</button>;
      })}
    </div>
  </div>;
}

function SummaryQuiz({data,onDone}){
  const[text,setText]=useState("");const[done,setDone]=useState(false);
  const len=[...text].length;const over=len>data.max;
  const submit=()=>{if(len===0||over)return;setDone(true);setTimeout(()=>onDone(over?0:1,1),1500);};
  return <div>
    <div style={{background:"#F9F5F0",borderRadius:12,padding:"14px",marginBottom:12,fontSize:12,lineHeight:1.7,color:P.text,borderLeft:`3px solid ${P.lav}`}}>
      <div style={{fontSize:10,color:P.muted,marginBottom:4}}>📖 原文のあらすじ</div>{data.passage}
    </div>
    <div style={{position:"relative",marginBottom:10}}>
      <textarea value={text} onChange={e=>setText(e.target.value)} disabled={done} placeholder={`${data.max}字以内で要約…`} rows={3}
        style={{width:"100%",boxSizing:"border-box",padding:"12px 14px",borderRadius:12,fontSize:13,border:`2px solid ${over?P.ng:done?P.ok:P.border}`,background:done?P.ok+"08":"#fff",color:P.text,fontFamily:"inherit",resize:"none",outline:"none",lineHeight:1.6}}/>
      <div style={{position:"absolute",bottom:8,right:12,fontSize:11,fontWeight:700,fontVariantNumeric:"tabular-nums",color:over?P.ng:len>data.max-5?P.gold:P.muted}}>{len}/{data.max}</div>
    </div>
    {done?<div style={{background:P.ok+"12",border:`1.5px solid ${P.ok}`,borderRadius:10,padding:"10px 14px",fontSize:12,color:P.ok,textAlign:"center"}}>✨ {len}字でまとめました！</div>
    :<button onClick={submit} disabled={len===0||over} style={{width:"100%",padding:"12px",borderRadius:12,fontSize:14,fontWeight:700,border:"none",background:len>0&&!over?P.accent:P.border,color:"#fff",cursor:len>0&&!over?"pointer":"default"}}>提出する</button>}
  </div>;
}

function OrderQuiz({data,onDone}){
  const item=data.items[0];const[order,setOrder]=useState(()=>shuffle(item.fragments));
  const[checked,setChecked]=useState(false);const[dragIdx,setDragIdx]=useState(null);
  const swap=(i,j)=>{if(checked)return;const n=[...order];[n[i],n[j]]=[n[j],n[i]];setOrder(n);};
  const check=()=>{setChecked(true);const ok=order.map(f=>f.id).join("")===item.correctOrder.join("");
    setTimeout(()=>onDone(ok?1:0,1),1500);};
  return <div>
    <div style={{fontSize:11,color:P.muted,marginBottom:10,textAlign:"center"}}>ドラッグまたはタップで順番を入れ替えよう</div>
    <div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:14}}>
      {order.map((f,i)=>{
        const isCorrectPos=checked&&f.id===item.correctOrder[i];
        return <div key={f.id} style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{width:24,height:24,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,fontWeight:700,background:checked?(isCorrectPos?P.ok:P.ng):P.lav,color:"#fff",flexShrink:0}}>{i+1}</span>
          <div style={{flex:1,padding:"10px 12px",borderRadius:10,fontSize:13,border:`1.5px solid ${checked?(isCorrectPos?P.ok:P.ng):P.border}`,background:checked?(isCorrectPos?P.ok+"10":P.ng+"10"):"#fff",color:P.text,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <span>{f.text}</span>
            {!checked&&<span style={{display:"flex",gap:4}}>
              {i>0&&<button onClick={()=>swap(i,i-1)} style={{background:"none",border:"none",fontSize:14,cursor:"pointer",padding:"2px"}}>↑</button>}
              {i<order.length-1&&<button onClick={()=>swap(i,i+1)} style={{background:"none",border:"none",fontSize:14,cursor:"pointer",padding:"2px"}}>↓</button>}
            </span>}
          </div>
        </div>;
      })}
    </div>
    {!checked&&<button onClick={check} style={{width:"100%",padding:"12px",borderRadius:12,fontSize:14,fontWeight:700,border:"none",background:P.accent,color:"#fff",cursor:"pointer"}}>この順番で確定</button>}
    {checked&&<div style={{textAlign:"center",fontSize:13,fontWeight:600,color:order.map(f=>f.id).join("")===item.correctOrder.join("")?P.ok:P.ng,marginTop:4}}>
      {order.map(f=>f.id).join("")===item.correctOrder.join("")?"✨ 正解！":"正しい順番: {item.correctOrder.map((id,i)=>item.fragments.find(f=>f.id===id)?.text).join(" → ")}"}
    </div>}
  </div>;
}

function BossBattle({data,onDone}){
  const items=data.items||[];
  const[step,setStep]=useState(0);const[sel,setSel]=useState(null);const[res,setRes]=useState(null);
  const[sc,setSc]=useState(0);const[hp,setHp]=useState(100);
  const item=items[step];if(!item)return null;
  const handle=(idx)=>{if(res!==null)return;setSel(idx);const ok=idx===item.ans;setRes(ok);
    if(ok){setSc(s=>s+1);setHp(h=>Math.max(0,h-20));}
    setTimeout(()=>{if(step<items.length-1){setStep(s=>s+1);setSel(null);setRes(null);}else onDone(sc+(ok?1:0),items.length);},1200);};
  return <div>
    <div style={{textAlign:"center",marginBottom:8}}>
      <div style={{fontSize:13,fontWeight:700,color:P.accent}}>⚡ ゼウス HP</div>
      <div style={{width:"100%",height:10,borderRadius:5,background:P.border,overflow:"hidden",marginTop:4}}>
        <div style={{width:`${hp}%`,height:"100%",borderRadius:5,background:`linear-gradient(90deg,${P.ng},${P.accent})`,transition:"width 0.6s cubic-bezier(0.34,1.56,0.64,1)"}}/>
      </div>
    </div>
    <ProgressDots total={items.length} current={step} done={step}/>
    <div style={{background:"linear-gradient(135deg,#2a1a3e,#1a1a2e)",borderRadius:14,padding:"20px 16px",textAlign:"center",marginBottom:14}}>
      <div style={{fontSize:36,marginBottom:6}}>{item.e}</div>
      <div style={{fontSize:14,fontWeight:600,color:"#E8E0D6"}}>{item.q}</div>
    </div>
    <div style={{display:"flex",flexDirection:"column",gap:8}}>
      {item.opts.map((o,i)=>{const isOk=res!==null&&i===item.ans;const isNg=res===false&&i===sel;
        return <button key={i} onClick={()=>handle(i)} style={{padding:"12px 14px",borderRadius:11,fontSize:13,textAlign:"left",border:`1.5px solid ${isOk?P.ok:isNg?P.ng:P.border}`,background:isOk?P.ok+"12":isNg?P.ng+"12":"#fff",color:P.text,cursor:res!==null?"default":"pointer",transition:"all 0.2s",display:"flex",alignItems:"center",gap:8}}>
          <span style={{width:22,height:22,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,flexShrink:0,background:isOk?P.ok:isNg?P.ng:P.border,color:isOk||isNg?"#fff":P.text}}>
            {isOk?"✓":isNg?"✗":String.fromCharCode(65+i)}
          </span>{o}
        </button>;
      })}
    </div>
  </div>;
}

function QuizRouter({qKey,onDone}){
  const data=QDB[qKey];if(!data)return <div style={{padding:20,textAlign:"center",color:P.muted}}>問題データなし</div>;
  if(qKey==="boss")return <BossBattle data={data} onDone={onDone}/>;
  if(data.blanks)return <BlankQuiz data={data} onDone={onDone}/>;
  if(data.words)return <KanjiQuiz data={data} onDone={onDone}/>;
  if(data.max)return <SummaryQuiz data={data} onDone={onDone}/>;
  if(data.items?.[0]?.fragments)return <OrderQuiz data={data} onDone={onDone}/>;
  return <SelectQuiz data={data} onDone={onDone}/>;
}

function StepMap({step,completedQs,currentQ,onQClick}){
  const s=STEPS[step-1];if(!s)return null;
  return <div style={{background:"linear-gradient(180deg,#F5EDE4,#EDE3D8)",borderRadius:16,padding:"16px",marginBottom:12}}>
    <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}>
      <span style={{fontSize:22}}>{s.icon}</span>
      <div>
        <div style={{fontSize:14,fontWeight:700,color:P.text}}>Step {s.id} — {s.name}</div>
        <div style={{fontSize:11,color:P.muted}}>{s.questions.length}問</div>
      </div>
    </div>
    <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
      {s.questions.map((qKey,i)=>{
        const done=completedQs.includes(qKey);const isCurrent=currentQ===qKey;
        const locked=!done&&!isCurrent;const d=QDB[qKey];
        return <button key={qKey} onClick={()=>!locked&&onQClick(qKey)} style={{
          flex:"1 1 auto",minWidth:80,padding:"10px 8px",borderRadius:12,border:`1.5px solid ${done?P.ok:isCurrent?P.accent+"88":P.border}`,
          background:done?P.ok+"10":isCurrent?"#fff":"#F5EDE4",cursor:locked?"default":"pointer",
          textAlign:"center",transition:"all 0.2s",opacity:locked?0.5:1,position:"relative",
        }}>
          {isCurrent&&<div style={{position:"absolute",top:-4,right:-4,width:10,height:10,borderRadius:"50%",background:P.accent,boxShadow:`0 0 6px ${P.accent}`}}/>}
          <div style={{fontSize:18}}>{done?"✅":qKey==="boss"?"⚡":"📝"}</div>
          <div style={{fontSize:10,fontWeight:600,color:P.text,marginTop:2}}>{d?.title?.replace(/問\d+\s*/,"")?.slice(0,6)||qKey}</div>
        </button>;
      })}
    </div>
  </div>;
}

function CardGallery({earned}){
  return <div>
    <div style={{textAlign:"center",marginBottom:12}}>
      <div style={{fontSize:13,fontWeight:700,color:P.text}}>🃏 神話カード図鑑</div>
      <div style={{fontSize:11,color:P.muted}}>{earned.length}/{ALL_CARDS.length} 収集済み</div>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8}}>
      {ALL_CARDS.map(c=>{const got=earned.includes(c.id);
        return <div key={c.id} style={{padding:"12px 6px",borderRadius:12,textAlign:"center",border:`1.5px solid ${got?c.color+"66":P.border}`,background:got?c.color+"08":"#F5EDE4",opacity:got?1:0.45,transition:"all 0.3s"}}>
          <div style={{fontSize:28}}>{got?c.e:"❓"}</div>
          <div style={{fontSize:9,color:c.color,letterSpacing:1,marginTop:2}}>{c.r}</div>
          <div style={{fontSize:10,fontWeight:600,color:P.text,marginTop:2}}>{got?c.name:"???"}</div>
          {got&&<div style={{fontSize:9,color:P.muted,marginTop:2}}>{c.desc}</div>}
        </div>;
      })}
    </div>
  </div>;
}

function StoryMode(){
  const[ch,setCh]=useState(0);
  return <div>
    <div style={{textAlign:"center",fontSize:13,fontWeight:700,color:P.text,marginBottom:10}}>📖 物語を読む</div>
    <div style={{display:"flex",gap:6,flexWrap:"wrap",justifyContent:"center",marginBottom:12}}>
      {STORY_CHAPTERS.map((c,i)=><button key={i} onClick={()=>setCh(i)} style={{padding:"6px 10px",borderRadius:8,fontSize:10,fontWeight:ch===i?700:400,border:`1px solid ${ch===i?P.accent:P.border}`,background:ch===i?P.accent+"12":"#fff",color:P.text,cursor:"pointer"}}>{c.icon}</button>)}
    </div>
    <div style={{background:"#F9F5F0",borderRadius:14,padding:"20px 16px",borderLeft:`3px solid ${P.lav}`}}>
      <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}>
        <span style={{fontSize:28}}>{STORY_CHAPTERS[ch].icon}</span>
        <div style={{fontSize:14,fontWeight:700,color:P.text}}>{STORY_CHAPTERS[ch].title}</div>
      </div>
      <div style={{fontSize:13,lineHeight:2,color:P.text}}>{STORY_CHAPTERS[ch].text}</div>
    </div>
  </div>;
}

export default function App(){
  const[screen,setScreen]=useState("title");
  const[activeStep,setActiveStep]=useState(1);
  const[activeQ,setActiveQ]=useState(null);
  const[completedQs,setCompletedQs]=useState([]);
  const[xp,setXp]=useState(0);
  const[streak]=useState(3);
  const[earned,setEarned]=useState([]);
  const[showCard,setShowCard]=useState(null);
  const[qKey2,setQKey2]=useState(0);
  const[tab,setTab]=useState("map");

  const currentQForStep=(s)=>{const st=STEPS[s-1];if(!st)return null;return st.questions.find(q=>!completedQs.includes(q))||null;};
  const stepDone=(s)=>{const st=STEPS[s-1];if(!st)return false;return st.questions.every(q=>completedQs.includes(q));};

  const handleQDone=(correct,total)=>{
    const earnedXp=correct*25+(correct===total?40:0);
    setXp(x=>x+earnedXp);
    if(activeQ)setCompletedQs(prev=>[...prev,activeQ]);
    if(correct>=Math.ceil(total*0.5)){
      const stepCards=ALL_CARDS.filter(c=>c.step===activeStep&&!earned.includes(c.id));
      if(stepCards.length>0){
        const nc=stepCards[0];
        setEarned(prev=>[...prev,nc.id]);
        setTimeout(()=>setShowCard(nc),500);
      }
    }
    setTimeout(()=>{setActiveQ(null);setScreen("main");},400);
  };

  const openQ=(qKey)=>{setActiveQ(qKey);setQKey2(k=>k+1);setScreen("quiz");};

  if(screen==="title"){
    return <div style={{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:"linear-gradient(180deg,#FFF8F3 0%,#F5EDE4 50%,#EDE3D8 100%)",fontFamily:"'Noto Sans JP','Hiragino Kaku Gothic ProN',sans-serif",padding:24,textAlign:"center"}}>
      <div style={{fontSize:56,marginBottom:8}}>🏛️</div>
      <h1 style={{fontSize:22,fontWeight:800,color:P.text,margin:0,letterSpacing:1}}>医神アスクレピオス</h1>
      <h2 style={{fontSize:14,fontWeight:500,color:P.accent,marginTop:4,letterSpacing:2}}>読解力クエスト</h2>
      <div style={{marginTop:20,padding:"14px 18px",borderRadius:14,background:"#ffffff88",maxWidth:280,fontSize:12,lineHeight:1.7,color:P.muted}}>
        ギリシャ神話の世界を冒険しながら<br/>全5Step・19問の読解力トレーニング<br/>
        <span style={{color:P.accent,fontWeight:600}}>カード12枚をすべて集めよう！</span>
      </div>
      <button onClick={()=>setScreen("main")} style={{marginTop:24,padding:"14px 44px",borderRadius:24,border:"none",background:`linear-gradient(135deg,${P.accent},${P.lav})`,color:"#fff",fontSize:15,fontWeight:700,cursor:"pointer",letterSpacing:2,boxShadow:`0 6px 20px ${P.accent}44`}}>
        冒険を始める
      </button>
      <div style={{marginTop:32,display:"flex",gap:16}}>
        {[{i:"☀️",l:"Step1"},{i:"🕊️",l:"Step2"},{i:"🐴",l:"Step3"},{i:"⚡",l:"Step4"},{i:"🌟",l:"BOSS"}].map((m,i)=>(
          <div key={i} style={{textAlign:"center",opacity:0.7}}>
            <div style={{fontSize:20}}>{m.i}</div>
            <div style={{fontSize:9,color:P.muted,marginTop:2}}>{m.l}</div>
          </div>
        ))}
      </div>
    </div>;
  }

  return <div style={{minHeight:"100vh",background:"linear-gradient(180deg,#FFF8F3,#F5EDE4)",fontFamily:"'Noto Sans JP','Hiragino Kaku Gothic ProN',sans-serif"}}>
    {showCard&&<CardReveal card={showCard} onClose={()=>setShowCard(null)}/>}

    {/* Header */}
    <div style={{padding:"10px 14px",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#ffffffcc",borderBottom:`1px solid ${P.border}`}}>
      <div style={{display:"flex",alignItems:"center",gap:6}}>
        <span style={{fontSize:18}}>🏛️</span>
        <div><div style={{fontSize:12,fontWeight:700,color:P.text}}>読解力クエスト</div></div>
      </div>
      <div style={{display:"flex",alignItems:"center",gap:10}}>
        <div style={{textAlign:"center"}}><div style={{fontSize:9,color:P.muted}}>ストリーク</div><div style={{fontSize:12,fontWeight:700,color:P.accent}}>🔥{streak}</div></div>
        <div style={{textAlign:"center"}}><div style={{fontSize:9,color:P.muted}}>カード</div><div style={{fontSize:12,fontWeight:700,color:P.gold}}>🃏{earned.length}/{ALL_CARDS.length}</div></div>
      </div>
    </div>

    {/* XP Bar */}
    <div style={{padding:"6px 14px 2px"}}>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:9,color:P.muted,marginBottom:3}}><span>XP</span><span>{xp}/800</span></div>
      <div style={{height:5,borderRadius:3,background:P.border,overflow:"hidden"}}>
        <div style={{width:`${Math.min((xp/800)*100,100)}%`,height:"100%",borderRadius:3,background:P.xpBar,transition:"width 0.6s cubic-bezier(0.34,1.56,0.64,1)"}}/>
      </div>
    </div>

    {/* Tab Nav */}
    {screen==="main"&&<div style={{display:"flex",gap:0,padding:"8px 14px 0"}}>
      {[{k:"map",l:"🗺️ マップ"},{k:"cards",l:"🃏 図鑑"},{k:"story",l:"📖 物語"}].map(t=>
        <button key={t.k} onClick={()=>setTab(t.k)} style={{flex:1,padding:"8px 0",borderRadius:tab===t.k?"10px 10px 0 0":"10px 10px 0 0",border:"none",fontSize:11,fontWeight:tab===t.k?700:400,background:tab===t.k?"#fff":"transparent",color:tab===t.k?P.text:P.muted,cursor:"pointer",borderBottom:tab===t.k?`2px solid ${P.accent}`:`1px solid ${P.border}`}}>{t.l}</button>
      )}
    </div>}

    <div style={{padding:"10px 14px 24px"}}>
      {screen==="main"&&tab==="map"&&<>
        {/* Step Selector */}
        <div style={{display:"flex",gap:6,marginBottom:10,overflowX:"auto",paddingBottom:4}}>
          {STEPS.map(s=>{
            const done=stepDone(s.id);const locked=s.id>1&&!stepDone(s.id-1)&&s.id!==activeStep;
            return <button key={s.id} onClick={()=>!locked&&setActiveStep(s.id)} style={{padding:"8px 12px",borderRadius:10,border:`1.5px solid ${activeStep===s.id?s.color:P.border}`,background:done?s.color+"12":activeStep===s.id?"#fff":"transparent",fontSize:10,fontWeight:activeStep===s.id?700:400,color:P.text,cursor:locked?"default":"pointer",whiteSpace:"nowrap",opacity:locked?0.4:1,display:"flex",alignItems:"center",gap:4,flexShrink:0}}>
              <span>{s.icon}</span>{done?"✅":"Step"+s.id}
            </button>;
          })}
        </div>
        <StepMap step={activeStep} completedQs={completedQs} currentQ={currentQForStep(activeStep)} onQClick={openQ}/>
        {/* Next Prompt */}
        {currentQForStep(activeStep)&&<div style={{marginTop:8,padding:"12px 14px",borderRadius:12,background:"#fff",border:`1.5px solid ${P.accent}28`,display:"flex",alignItems:"center",gap:10}}>
          <div style={{width:36,height:36,borderRadius:10,background:P.accent+"12",display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>📝</div>
          <div style={{flex:1}}>
            <div style={{fontSize:12,fontWeight:600,color:P.text}}>{QDB[currentQForStep(activeStep)]?.title}</div>
            <div style={{fontSize:10,color:P.muted,marginTop:1}}>{QDB[currentQForStep(activeStep)]?.sub}</div>
          </div>
          <button onClick={()=>openQ(currentQForStep(activeStep))} style={{padding:"8px 14px",borderRadius:10,border:"none",background:P.accent,color:"#fff",fontSize:11,fontWeight:700,cursor:"pointer",flexShrink:0}}>挑戦</button>
        </div>}
        {stepDone(activeStep)&&activeStep<5&&<div style={{marginTop:8,textAlign:"center"}}>
          <button onClick={()=>setActiveStep(activeStep+1)} style={{padding:"12px 32px",borderRadius:12,border:"none",background:`linear-gradient(135deg,${P.accent},${P.lav})`,color:"#fff",fontSize:13,fontWeight:700,cursor:"pointer"}}>
            次の章へ → Step {activeStep+1}
          </button>
        </div>}
        {activeStep===5&&stepDone(5)&&<div style={{marginTop:12,textAlign:"center",padding:"20px",background:"linear-gradient(135deg,#E8C87220,#D4877F20)",borderRadius:16}}>
          <div style={{fontSize:40}}>🎉</div>
          <div style={{fontSize:16,fontWeight:800,color:P.text,marginTop:8}}>全ステージクリア！</div>
          <div style={{fontSize:12,color:P.muted,marginTop:4}}>おめでとうございます！{earned.length}枚のカードを獲得しました</div>
        </div>}
      </>}

      {screen==="main"&&tab==="cards"&&<CardGallery earned={earned}/>}
      {screen==="main"&&tab==="story"&&<StoryMode/>}

      {screen==="quiz"&&<div style={{background:"#fff",borderRadius:16,padding:"16px 14px",boxShadow:"0 2px 12px rgba(0,0,0,0.04)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <button onClick={()=>{setActiveQ(null);setScreen("main");}} style={{background:"none",border:"none",fontSize:12,color:P.muted,cursor:"pointer"}}>← 戻る</button>
          {activeQ&&QDB[activeQ]&&<div style={{fontSize:9,padding:"3px 8px",borderRadius:6,background:P.lav+"18",color:P.lav,fontWeight:600}}>{QDB[activeQ].mechanic}</div>}
        </div>
        {activeQ&&QDB[activeQ]&&<>
          <div style={{fontSize:15,fontWeight:700,color:P.text,marginBottom:2}}>{QDB[activeQ].title}</div>
          <div style={{fontSize:11,color:P.muted,marginBottom:14}}>{QDB[activeQ].sub}</div>
        </>}
        <QuizRouter key={qKey2} qKey={activeQ} onDone={handleQDone}/>
      </div>}
    </div>
  </div>;
}
